import { database } from './firebase-config.js';
import { checkAuth } from './auth-check.js';
import { ref, get } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js";

let allEscalas = [];
let filteredEscalas = [];
let currentPage = 1;
const itemsPerPage = 15;
let uniqueStations = new Set();
let uniqueYears = new Set();
let currentSearchType = 'RE';

export async function initEscalasSPA() {
    console.log('📅 Escalas SPA inicializando...');
    
    try {
        const { userData, re } = await checkAuth(3);
        
        sessionStorage.setItem('userRE', re);
        sessionStorage.setItem('userName', userData.nome);
        
        if (window.updateUserGreetingInSPA) {
            window.updateUserGreetingInSPA();
        }
        
        await setupEscalas();
        
    } catch (error) {
        console.error('❌ Erro no escalas SPA:', error);
        showError('Erro: ' + error.message);
    }
}

async function initEscalas() {
    console.log('📅 Página de Escalas carregando...');
    
    try {
        const { userData, re } = await checkAuth(3);
        
        sessionStorage.setItem('userRE', re);
        sessionStorage.setItem('userName', userData.nome);
        
        await loadNavbar();
        await setupEscalas();
        
    } catch (error) {
        console.error('❌ Erro ao carregar escalas:', error);
        if (error.message.includes('Nível de acesso insuficiente')) {
            alert('Você não tem permissão para acessar esta página.');
            window.location.href = 'dashboard.html';
        }
    }
}

async function setupEscalas() {
    setupEventListeners();
    await loadEscalados();
    populateFilters();
    applyFilters();
}

async function loadEscalados() {
    try {
        showLoading(true);
        
        const escaladosRef = ref(database, 'escalados');
        const snapshot = await get(escaladosRef);
        
        if (snapshot.exists()) {
            allEscalas = [];
            uniqueStations.clear();
            uniqueYears.clear();
            
            snapshot.forEach((childSnapshot) => {
                const escala = childSnapshot.val();
                const linhaKey = childSnapshot.key;
                
                if (linhaKey === 'linha1') return;
                
                escala.linhaId = linhaKey;
                
                if (escala.HorarioInic) {
                    escala.horarioInicio = decimalToTime(escala.HorarioInic);
                }
                if (escala.HorarioTerm) {
                    escala.horarioTermino = decimalToTime(escala.HorarioTerm);
                }
                
                escala.horarioFormatado = `${escala.horarioInicio || '--:--'} às ${escala.horarioTermino || '--:--'}`;
                
                escala.Data = escala.Data || '';
                
                if (escala.Data) {
                    const parts = escala.Data.split('/');
                    if (parts.length === 3) {
                        const year = parseInt(parts[2]);
                        if (year > 2000 && year < 2100) {
                            escala.ano = year;
                            uniqueYears.add(year);
                        }
                    }
                }
                
                if (escala.mês) {
                    const monthNames = ['', 'Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
                    escala.mesNome = monthNames[parseInt(escala.mês)] || escala.mês;
                }
                
                allEscalas.push(escala);
                
                if (escala.Estacao) {
                    uniqueStations.add(escala.Estacao);
                }
            });
            
            allEscalas.sort((a, b) => {
                const dateA = parseDate(a.Data);
                const dateB = parseDate(b.Data);
                return dateB - dateA;
            });
            
            console.log(`✅ ${allEscalas.length} escalas carregadas`);
            
        } else {
            console.log('📭 Nenhuma escala encontrada');
            allEscalas = [];
            showMessage('Nenhuma escala cadastrada no sistema.', 'info');
        }
        
    } catch (error) {
        console.error('💥 Erro ao carregar escalas:', error);
        showError('Erro ao carregar escalas: ' + error.message);
    } finally {
        showLoading(false);
    }
}

function refreshEscalas() {
    console.log('🔄 Atualizando escalas...');
    
    const refreshBtn = document.getElementById('refreshData');
    if (refreshBtn) {
        const originalHTML = refreshBtn.innerHTML;
        refreshBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Atualizando...';
        refreshBtn.disabled = true;
        
        loadEscalados().finally(() => {
            setTimeout(() => {
                refreshBtn.innerHTML = originalHTML;
                refreshBtn.disabled = false;
                showMessage('Dados atualizados com sucesso', 'success');
            }, 500);
        });
    } else {
        loadEscalados();
    }
}

function decimalToTime(decimal) {
    const totalMinutes = Math.round(decimal * 24 * 60);
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
}

function parseDate(dateString) {
    if (!dateString) return new Date();
    const [day, month, year] = dateString.split('/').map(Number);
    return new Date(year || new Date().getFullYear(), (month || 1) - 1, day || 1);
}

function formatDate(dateString) {
    if (!dateString) return '-';
    try {
        const date = parseDate(dateString);
        return date.toLocaleDateString('pt-BR', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric'
        });
    } catch {
        return dateString;
    }
}

function setupEventListeners() {
    const searchInput = document.getElementById('searchRE');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            if (currentSearchType === 'RE') {
                this.value = this.value.replace(/\D/g, '').slice(0, 6);
            }
            applyFilters();
        });
        
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') applyFilters();
        });
    }
    
    const searchTypeSelect = document.getElementById('searchType');
    if (searchTypeSelect) {
        searchTypeSelect.addEventListener('change', function() {
            currentSearchType = this.value;
            const searchInput = document.getElementById('searchRE');
            if (searchInput) {
                searchInput.placeholder = `Filtrar por ${getSearchPlaceholder(currentSearchType)}`;
                searchInput.value = '';
                applyFilters();
            }
        });
    }
    
    const monthFilter = document.getElementById('filterMonth');
    if (monthFilter) monthFilter.addEventListener('change', applyFilters);
    
    const yearFilter = document.getElementById('filterYear');
    if (yearFilter) yearFilter.addEventListener('change', applyFilters);
    
    const stationFilter = document.getElementById('filterStation');
    if (stationFilter) stationFilter.addEventListener('change', applyFilters);
    
    const clearBtn = document.getElementById('clearFilters');
    if (clearBtn) clearBtn.addEventListener('click', clearFilters);
    
    const refreshBtn = document.getElementById('refreshData');
    if (refreshBtn) refreshBtn.addEventListener('click', refreshEscalas);
    
    const exportBtn = document.getElementById('exportExcel');
    if (exportBtn) exportBtn.addEventListener('click', exportToExcel);
}

function getSearchPlaceholder(type) {
    const placeholders = {
        'RE': 'RE (6 dígitos)',
        'Militar': 'Nome do militar',
        'OPM': 'OPM',
        'Estacao': 'Estação',
        'Composicao': 'Composição',
        'ID': 'ID da escala'
    };
    return placeholders[type] || 'Buscar...';
}

function populateFilters() {
    const stationFilter = document.getElementById('filterStation');
    if (stationFilter) {
        const sortedStations = Array.from(uniqueStations).sort();
        
        while (stationFilter.options.length > 1) {
            stationFilter.remove(1);
        }
        
        sortedStations.forEach(station => {
            const option = document.createElement('option');
            option.value = station;
            option.textContent = station;
            stationFilter.appendChild(option);
        });
    }
    
    const yearFilter = document.getElementById('filterYear');
    if (yearFilter) {
        const sortedYears = Array.from(uniqueYears).sort((a, b) => b - a);
        
        while (yearFilter.options.length > 1) {
            yearFilter.remove(1);
        }
        
        sortedYears.forEach(year => {
            const option = document.createElement('option');
            option.value = year;
            option.textContent = year;
            if (year === new Date().getFullYear()) {
                option.selected = true;
            }
            yearFilter.appendChild(option);
        });
    }
}

function applyFilters() {
    const searchValue = document.getElementById('searchRE').value.trim();
    const monthFilter = document.getElementById('filterMonth').value;
    const yearFilter = document.getElementById('filterYear').value;
    const stationFilter = document.getElementById('filterStation').value;
    
    filteredEscalas = allEscalas.filter(escala => {
        if (searchValue) {
            const searchField = currentSearchType.toLowerCase();
            let fieldValue = '';
            
            switch(currentSearchType) {
                case 'RE':
                    fieldValue = escala.RE ? escala.RE.toString() : '';
                    break;
                case 'Militar':
                    fieldValue = escala.Militar || '';
                    break;
                case 'OPM':
                    fieldValue = escala.OPM || '';
                    break;
                case 'Estacao':
                    fieldValue = escala.Estacao || '';
                    break;
                case 'Composicao':
                    fieldValue = escala.Composicao || '';
                    break;
                case 'ID':
                    fieldValue = escala.Id || '';
                    break;
            }
            
            if (!fieldValue.toLowerCase().includes(searchValue.toLowerCase())) {
                return false;
            }
        }
        
        if (monthFilter && escala.mês) {
            if (escala.mês.toString() !== monthFilter) {
                return false;
            }
        }
        
        if (yearFilter && escala.ano) {
            if (escala.ano.toString() !== yearFilter) {
                return false;
            }
        }
        
        if (stationFilter && escala.Estacao) {
            if (escala.Estacao !== stationFilter) {
                return false;
            }
        }
        
        return true;
    });
    
    currentPage = 1;
    renderTable();
    updateStatistics();
}

function clearFilters() {
    document.getElementById('searchRE').value = '';
    document.getElementById('filterMonth').value = '';
    document.getElementById('filterYear').value = '';
    document.getElementById('filterStation').value = '';
    
    currentSearchType = 'RE';
    const searchTypeSelect = document.getElementById('searchType');
    if (searchTypeSelect) searchTypeSelect.value = 'RE';
    
    const searchInput = document.getElementById('searchRE');
    if (searchInput) searchInput.placeholder = 'Filtrar por RE (6 dígitos)';
    
    filteredEscalas = [...allEscalas];
    currentPage = 1;
    renderTable();
    updateStatistics();
    
    showMessage('Filtros limpos com sucesso.', 'success');
}

function renderTable() {
    const tbody = document.getElementById('escalasBody');
    const noDataDiv = document.getElementById('noData');
    const infoText = document.getElementById('infoText');
    const pagination = document.getElementById('pagination');
    
    if (!tbody || !noDataDiv || !infoText || !pagination) {
        console.error('❌ Elementos da tabela não encontrados');
        return;
    }
    
    if (filteredEscalas.length === 0) {
        tbody.innerHTML = '';
        noDataDiv.classList.remove('d-none');
        infoText.textContent = 'Mostrando 0 de 0 registros';
        pagination.innerHTML = '';
        return;
    }
    
    noDataDiv.classList.add('d-none');
    
    const totalPages = Math.ceil(filteredEscalas.length / itemsPerPage);
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = Math.min(startIndex + itemsPerPage, filteredEscalas.length);
    const pageEscalas = filteredEscalas.slice(startIndex, endIndex);
    
    let html = '';
    const userRE = sessionStorage.getItem('userRE');
    
    pageEscalas.forEach((escala, index) => {
        const globalIndex = startIndex + index + 1;
        const isUserEscala = userRE && escala.RE && escala.RE.toString() === userRE;
        const escalaId = escala.Id || '-';
        
        const mesmaEscalaAnterior = index > 0 && pageEscalas[index-1].Id === escalaId;
        const mesmaEscalaPosterior = index < pageEscalas.length-1 && pageEscalas[index+1].Id === escalaId;
        
        let rowClass = '';
        if (isUserEscala) rowClass += 'table-info ';
        if (escalaId !== '-' && (mesmaEscalaAnterior || mesmaEscalaPosterior)) {
            rowClass += 'escala-repetida ';
        }
        
        html += `
            <tr class="${rowClass.trim()}" data-escala-id="${escala.linhaId}" data-escala-original-id="${escalaId}">
                <td>
                    <div class="fw-bold">${formatDate(escala.Data)}</div>
                    <small class="text-muted">${escala.mesNome || ''}</small>
                </td>
                <td>${escala.horarioFormatado || '-'}</td>
                <td>${escala.OPM || '-'}</td>
                <td>
                    <span class="badge bg-secondary">${escala.Estacao || '-'}</span>
                </td>
                <td>
                    <span class="badge ${getComposicaoColor(escala.Composicao)}">
                        ${escala.Composicao || '-'}
                    </span>
                </td>
                <td>${escala.Posto_Grad || '-'}</td>
                <td>
                    <span class="badge bg-dark">${escala.RE || '-'}</span>
                    ${isUserEscala ? '<small class="text-primary d-block">(Você)</small>' : ''}
                </td>
                <td>
                    <div class="fw-bold">${escala.Militar || '-'}</div>
                </td>
                <td>
                    <small class="text-muted">${escalaId}</small>
                    ${escalaId !== '-' && getEscalaCount(escalaId) > 1 ? 
                        `<span class="badge bg-info ms-1">×${getEscalaCount(escalaId)}</span>` : ''}
                </td>
                <td>
                    <button class="btn btn-sm btn-outline-secondary" title="Confirmar escala" onclick="openConfirmModal('${escala.linhaId}')">
                        <i class="far fa-clock"></i>
                    </button>
                </td>
            </tr>
        `;
    });
    
    tbody.innerHTML = html;
    infoText.textContent = `Mostrando ${startIndex + 1} a ${endIndex} de ${filteredEscalas.length} registros`;
    renderPagination(totalPages);
    
    applyEscalaGroupStyling();
}

function getEscalaCount(escalaId) {
    if (!escalaId || escalaId === '-') return 0;
    return filteredEscalas.filter(e => e.Id === escalaId).length;
}

function applyEscalaGroupStyling() {
    const rows = document.querySelectorAll('#escalasBody tr');
    let currentGroup = null;
    let groupIndex = 0;
    
    rows.forEach((row, index) => {
        const escalaId = row.getAttribute('data-escala-original-id');
        
        if (escalaId !== currentGroup) {
            currentGroup = escalaId;
            groupIndex++;
        }
        
        if (escalaId !== '-' && getEscalaCount(escalaId) > 1) {
            if (groupIndex % 2 === 0) {
                row.style.backgroundColor = 'rgba(0, 123, 255, 0.05)';
            } else {
                row.style.backgroundColor = 'rgba(108, 117, 125, 0.05)';
            }
        }
    });
}

function getComposicaoColor(composicao) {
    if (!composicao) return 'bg-secondary';
    
    const cores = {
        'INCÊNDIO OU RESGATE': 'bg-danger',
        'GUARNIÇÃO DE SALVAMENTO': 'bg-success',
        'RESGATE': 'bg-warning',
        'SOCORRO': 'bg-info',
        'EMERGÊNCIA': 'bg-primary'
    };
    
    for (const [key, value] of Object.entries(cores)) {
        if (composicao.includes(key)) return value;
    }
    
    return 'bg-secondary';
}

function renderPagination(totalPages) {
    const pagination = document.getElementById('pagination');
    
    if (totalPages <= 1) {
        pagination.innerHTML = '';
        return;
    }
    
    let html = '';
    
    html += `
        <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
            <a class="page-link" href="#" onclick="changePage(${currentPage - 1})">
                <i class="fas fa-chevron-left"></i>
            </a>
        </li>
    `;
    
    const maxPagesToShow = 5;
    let startPage = Math.max(1, currentPage - Math.floor(maxPagesToShow / 2));
    let endPage = Math.min(totalPages, startPage + maxPagesToShow - 1);
    
    if (endPage - startPage + 1 < maxPagesToShow) {
        startPage = Math.max(1, endPage - maxPagesToShow + 1);
    }
    
    for (let i = startPage; i <= endPage; i++) {
        html += `
            <li class="page-item ${i === currentPage ? 'active' : ''}">
                <a class="page-link" href="#" onclick="changePage(${i})">${i}</a>
            </li>
        `;
    }
    
    html += `
        <li class="page-item ${currentPage === totalPages ? 'disabled' : ''}">
            <a class="page-link" href="#" onclick="changePage(${currentPage + 1})">
                <i class="fas fa-chevron-right"></i>
            </a>
        </li>
    `;
    
    pagination.innerHTML = html;
}

window.changePage = function(page) {
    if (page < 1 || page > Math.ceil(filteredEscalas.length / itemsPerPage)) return;
    currentPage = page;
    renderTable();
    window.scrollTo({ top: 0, behavior: 'smooth' });
};

window.openConfirmModal = function(linhaId) {
    console.log('Abrindo modal para linha:', linhaId);
    showMessage('Funcionalidade em desenvolvimento', 'info');
};

function updateStatistics() {
    const totalEscalas = document.getElementById('totalEscalas');
    const totalEstacoes = document.getElementById('totalEstacoes');
    const totalMilitares = document.getElementById('totalMilitares');
    const mesAtual = document.getElementById('mesAtual');
    const anoAtual = document.getElementById('anoAtual');
    
    if (!totalEscalas || !totalEstacoes || !totalMilitares || !mesAtual || !anoAtual) return;
    
    totalEscalas.textContent = filteredEscalas.length;
    totalEstacoes.textContent = getUniqueStationsCount();
    totalMilitares.textContent = getUniqueMilitaresCount();
    
    const now = new Date();
    const monthNames = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
    mesAtual.textContent = monthNames[now.getMonth()];
    
    const yearFilter = document.getElementById('filterYear');
    if (yearFilter && yearFilter.value) {
        anoAtual.textContent = yearFilter.value;
    } else {
        anoAtual.textContent = now.getFullYear();
    }
}

function getUniqueStationsCount() {
    const stations = new Set();
    filteredEscalas.forEach(escala => {
        if (escala.Estacao) stations.add(escala.Estacao);
    });
    return stations.size;
}

function getUniqueMilitaresCount() {
    const militares = new Set();
    filteredEscalas.forEach(escala => {
        if (escala.RE) militares.add(escala.RE);
    });
    return militares.size;
}

function exportToExcel() {
    try {
        if (filteredEscalas.length === 0) {
            showMessage('Nenhum dado para exportar!', 'warning');
            return;
        }
        
        const wsData = filteredEscalas.map(escala => ({
            'Data': escala.Data || '',
            'Horário': escala.horarioFormatado || '',
            'OPM': escala.OPM || '',
            'Estação': escala.Estacao || '',
            'Composição': escala.Composicao || '',
            'Posto/Grad': escala.Posto_Grad || '',
            'RE': escala.RE || '',
            'Militar': escala.Militar || '',
            'ID': escala.Id || '',
            'Mês': escala.mês || '',
            'Ano': escala.ano || ''
        }));
        
        const ws = XLSX.utils.json_to_sheet(wsData);
        
        const wscols = [
            {wch: 10}, {wch: 15}, {wch: 10}, {wch: 15}, {wch: 20},
            {wch: 12}, {wch: 8}, {wch: 25}, {wch: 10}, {wch: 5}, {wch: 6}
        ];
        ws['!cols'] = wscols;
        
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Escalas');
        
        const today = new Date().toISOString().split('T')[0];
        const fileName = `escalas_${today}.xlsx`;
        
        XLSX.writeFile(wb, fileName);
        
        showMessage(`Arquivo ${fileName} gerado com sucesso!`, 'success');
        
    } catch (error) {
        console.error('💥 Erro ao exportar:', error);
        showError('Erro ao exportar para Excel: ' + error.message);
    }
}

function showLoading(show) {
    const tbody = document.getElementById('escalasBody');
    const noDataDiv = document.getElementById('noData');
    
    if (show) {
        if (tbody) tbody.innerHTML = `
            <tr>
                <td colspan="10" class="text-center py-4">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Carregando...</span>
                    </div>
                    <p class="mt-2 text-muted">Carregando escalas...</p>
                </td>
            </tr>
        `;
        if (noDataDiv) noDataDiv.classList.add('d-none');
    }
}

function showMessage(message, type = 'info') {
    const existingAlerts = document.querySelectorAll('.temp-alert');
    existingAlerts.forEach(alert => alert.remove());
    
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} temp-alert alert-dismissible fade show position-fixed`;
    alertDiv.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    alertDiv.innerHTML = `
        <div class="d-flex align-items-center">
            <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'} me-2"></i>
            <div>${message}</div>
            <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    document.body.appendChild(alertDiv);
    
    setTimeout(() => {
        if (alertDiv.parentNode) alertDiv.remove();
    }, 3000);
}

function showError(message) {
    showMessage(message, 'danger');
}

async function loadNavbar() {
    try {
        const { loadNavbar } = await import('./auth-check.js');
        return loadNavbar();
    } catch (error) {
        console.warn('⚠️ Não foi possível carregar navbar:', error);
    }
}

if (!window.location.pathname.includes('app.html')) {
    document.addEventListener('DOMContentLoaded', initEscalas);
}